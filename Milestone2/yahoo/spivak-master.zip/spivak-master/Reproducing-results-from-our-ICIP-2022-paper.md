Stay tuned!  Instructions for reproducing the experiments
from our ICIP paper should be coming soon.

<!--

This section describes how to reproduce some results
from our [ICIP 2022](https://2022.ieeeicip.org/) paper.

- [Temporally Precise Action Spotting in Soccer Videos Using
Dense Detection Anchors](https://arxiv.org/abs/2205.10450).
In ICIP, 2022.

-->
